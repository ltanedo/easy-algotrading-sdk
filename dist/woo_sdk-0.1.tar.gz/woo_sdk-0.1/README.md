# woo algo trading sdk
A python developer kit for rapid algo trading development, notably the use of event callbacks and strategies as modular classes.
